#!/usr/bin/env python
# coding: utf-8

# In[1]:


# The original .beadedbag.py file has been moved to 
# .utils. This file serves as a placeholder to maintain compatibility.

from pyIClab.utils.beadedbag import *


# In[ ]:




